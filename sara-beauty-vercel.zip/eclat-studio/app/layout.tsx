import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Sara Beauty | Salon de coiffure & esthétique',description:'Coiffure, soins visage, beauté des mains et pieds, maquillage et bien-être à Salé.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
