import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'ÉCLAT Studio | Salon de beauté & esthétique',description:'Coiffure, soins visage, beauté des mains et pieds, maquillage et bien-être à Fès.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
