# ÉCLAT Studio — Salon de beauté

Site vitrine multi-pages prêt pour Next.js et Vercel.

## Pages
- `/` : accueil / landing page
- `/services` : catalogue des prestations et tarifs en MAD
- `/a-propos` : présentation du salon
- `/contact` : coordonnées et réservation WhatsApp

## Lancer en local
```bash
npm install
npm run dev
```
Puis ouvrir http://localhost:3000.

## Déployer sur Vercel
1. Créer un dépôt GitHub et y envoyer le contenu de ce dossier.
2. Dans Vercel, choisir **Add New → Project** puis importer le dépôt GitHub.
3. Garder les réglages Next.js par défaut et cliquer sur **Deploy**.

## Personnalisation avant publication
- Remplacer « ÉCLAT Studio » par le vrai nom du salon.
- Dans `components/Site.tsx` et `app/contact/page.tsx`, remplacer le numéro WhatsApp et les coordonnées.
- Mettre à jour l'adresse, les horaires, Instagram et e-mail.
- Vérifier et ajuster les prix proposés selon vos tarifs réels.
- Remplacer la photo distante de la page d'accueil si vous disposez de photos du salon.

Les prix sont des suggestions indicatives en dirhams marocains (MAD), pas des tarifs confirmés du salon.
